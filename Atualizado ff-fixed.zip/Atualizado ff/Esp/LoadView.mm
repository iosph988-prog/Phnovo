#import "IMGUI/imgui.h"
#import <UIKit/UIKit.h>
#include "Includes.h"
#import "menuIcon.h"
#import "Esp/Obfuscate.h"
#import "API/APIClient.h"
#import "../LicenseGate.h"
#include "oxorany/oxorany_include.h"

// Extern hack_thread de savage.mm
extern void *hack_thread(void *);
//#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^

@interface MenuLoad ()
@property (nonatomic, strong) ImGuiDrawView *vna;
- (ImGuiDrawView *)GetImGuiView;
@end

static MenuLoad *extraInfo;

UIButton* InvisibleMenuButton;
UIButton* VisibleMenuButton;
MenuInteraction* menuTouchView;
UITextField* hideRecordTextfield;
UIView* hideRecordView;

@interface MenuInteraction()
@end

@implementation MenuInteraction

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    extern ImVec2 menuPos;
    extern ImVec2 menuSize;
    CGRect touchableArea = CGRectMake(menuPos.x, menuPos.y, menuSize.x, menuSize.y);
    if (CGRectContainsPoint(touchableArea, point)) {
        return [super pointInside:point withEvent:event];
    }
    return NO;
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if ([ImGuiDrawView isMenuShowing]) { [[extraInfo GetImGuiView] updateIOWithTouchEvent:event]; }
    [super touchesBegan:touches withEvent:event]; // repassa para o jogo
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if ([ImGuiDrawView isMenuShowing]) { [[extraInfo GetImGuiView] updateIOWithTouchEvent:event]; }
    [super touchesMoved:touches withEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if ([ImGuiDrawView isMenuShowing]) { [[extraInfo GetImGuiView] updateIOWithTouchEvent:event]; }
    [super touchesCancelled:touches withEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if ([ImGuiDrawView isMenuShowing]) { [[extraInfo GetImGuiView] updateIOWithTouchEvent:event]; }
    [super touchesEnded:touches withEvent:event];
}

@end

@implementation MenuLoad

- (ImGuiDrawView*) GetImGuiView
{
    return _vna;
}
/*
static void didFinishLaunching(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef info)
{   
    timer(5) {
        extraInfo = [MenuLoad new];
         PPAPIKey *APIKey = [[PPAPIKey alloc] init];
        [APIKey setPackageToken:NSSENCRYPT("bCpvk7vy0IFkVy5l6TQq6VZhvJ4HvrdOV7HTIKeXH9KLzlV0se4as1onWA19sxTU8uL5oTGlqrT0wVU2SqbkbEu8cYBW8NjKMEx7")];
        [APIKey setAppVersion:NSSENCRYPT("1.0")];
        [APIKey setENLanguage:YES];
        [APIKey loading:^{
            [extraInfo initTapGes];
        }];
    });
}*/


static void didFinishLaunching(CFNotificationCenterRef center,
                               void *observer,
                               CFStringRef name,
                               const void *object,
                               CFDictionaryRef info)
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        UIWindow *window = UIApplication.sharedApplication.keyWindow;
        if (!window && UIApplication.sharedApplication.windows.count > 0) window = UIApplication.sharedApplication.windows.firstObject;
        [LicenseGate presentForWindow:window success:^{
            dispatch_async(dispatch_get_main_queue(), ^{
                extraInfo = [MenuLoad new];
                [extraInfo initTapGes];

                pthread_t hacks;
                pthread_create(&hacks, NULL, hack_thread, NULL);
            });
        });
}

__attribute__((constructor)) static void initialize()
{
    CFNotificationCenterAddObserver(CFNotificationCenterGetLocalCenter(), NULL, &didFinishLaunching, (CFStringRef)UIApplicationDidFinishLaunchingNotification, NULL, CFNotificationSuspensionBehaviorDrop);
}

-(void)initTapGes
{
    // Obtém keyWindow compatível com iOS 13+
    UIWindow *keyWindow = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if ([scene isKindOfClass:[UIWindowScene class]]) {
            UIWindowScene *ws = (UIWindowScene *)scene;
            for (UIWindow *w in ws.windows) {
                if (w.isKeyWindow) { keyWindow = w; break; }
            }
        }
        if (keyWindow) break;
    }
    if (!keyWindow) keyWindow = UIApplication.sharedApplication.windows.firstObject;
    UIView* mainView = keyWindow.rootViewController.view;
    if (!mainView) mainView = keyWindow;
    hideRecordTextfield = [[UITextField alloc] init];
    hideRecordView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height)];
    [hideRecordView setBackgroundColor:[UIColor clearColor]];
    [hideRecordView setUserInteractionEnabled:YES];
    hideRecordTextfield.secureTextEntry = true;
    [hideRecordView addSubview:hideRecordTextfield];
    CALayer *layer = hideRecordTextfield.layer;
    if ([layer.sublayers.firstObject.delegate isKindOfClass:[UIView class]]) {
        hideRecordView = (UIView *)layer.sublayers.firstObject.delegate;
    } else {
        hideRecordView = nil;
    }

    [keyWindow addSubview:hideRecordView];
    
    if (!_vna) {
         ImGuiDrawView *vc = [[ImGuiDrawView alloc] init];
         _vna = vc;
         _vna.view.multipleTouchEnabled = YES; // Garantir multitouch no ImGui
    }
     
    [ImGuiDrawView showChange:false];
_vna.view.userInteractionEnabled = NO;
    [hideRecordView addSubview:_vna.view];

    menuTouchView = [[MenuInteraction alloc] initWithFrame:mainView.frame];
    menuTouchView.multipleTouchEnabled = YES;
menuTouchView.multipleTouchEnabled = YES;
    [[UIApplication sharedApplication].windows[0].rootViewController.view addSubview:menuTouchView];

    NSData* data = [[NSData alloc] initWithBase64EncodedString:menuIcon options:0];
    (void)[UIImage imageWithData:data];

    InvisibleMenuButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    InvisibleMenuButton.frame = CGRectMake(10, 10, 50, 50);
    InvisibleMenuButton.backgroundColor = [UIColor clearColor];
    InvisibleMenuButton.multipleTouchEnabled = YES;
    InvisibleMenuButton.multipleTouchEnabled = YES;
[InvisibleMenuButton addTarget:self action:@selector(buttonDragged:withEvent:) forControlEvents:UIControlEventTouchDragInside];
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showMenu:)];
    [InvisibleMenuButton addGestureRecognizer:tapGestureRecognizer];
    [[UIApplication sharedApplication].windows[0].rootViewController.view addSubview:InvisibleMenuButton];
    
    VisibleMenuButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    VisibleMenuButton.frame = CGRectMake(10, 10, 50, 50);
    VisibleMenuButton.backgroundColor = [UIColor clearColor];
    VisibleMenuButton.layer.cornerRadius = VisibleMenuButton.frame.size.width * 0.5f;
    VisibleMenuButton.multipleTouchEnabled = YES;
VisibleMenuButton.multipleTouchEnabled = YES;
    [hideRecordView addSubview:VisibleMenuButton];

    // Triple tap (3 dedos) para abrir menu
    UITapGestureRecognizer *tripleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showMenu:)];
    tripleTapGesture.numberOfTapsRequired = 2;
    tripleTapGesture.numberOfTouchesRequired = 3;
    [mainView addGestureRecognizer:tripleTapGesture];
    
    // Adicionar também na window para garantir
    UITapGestureRecognizer *tripleTapGestureWindow = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showMenu:)];
    tripleTapGestureWindow.numberOfTapsRequired = 2;
    tripleTapGestureWindow.numberOfTouchesRequired = 3;
    [keyWindow addGestureRecognizer:tripleTapGestureWindow];
}


- (void)showMenu:(UITapGestureRecognizer *)tapGestureRecognizer {
    if (tapGestureRecognizer.state == UIGestureRecognizerStateEnded) {
        BOOL open = ![ImGuiDrawView isMenuShowing];
        [ImGuiDrawView showChange:open];
        if (_vna && _vna.view) {
            _vna.view.userInteractionEnabled = open;
        }
    }
}

- (void)buttonDragged:(UIButton *)button withEvent:(UIEvent *)event
{
    UITouch *touch = [[event touchesForView:button] anyObject];

    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    CGFloat delta_y = location.y - previousLocation.y;

    button.center = CGPointMake(button.center.x + delta_x, button.center.y + delta_y);

    VisibleMenuButton.center = button.center;
    VisibleMenuButton.frame = button.frame;
}

@end
