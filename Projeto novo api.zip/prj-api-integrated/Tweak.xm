#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <Security/Security.h>

#define LOG(fmt, ...) NSLog(@"[KeyBypass] " fmt, ##__VA_ARGS__)

static NSString *const kKeychainService = @"com.3105.ios-key";
static NSString *const kKeychainAccount = @"proxy-system-key";
static NSString *const kFakeKey         = @"BYPASS-0000-0000-0000";

#pragma mark - Payload falso (cobre envelope tRPC E objeto plano)

static NSData *FakeCheckPayload(void) {
    NSString *json =
    @"{"
      "\"success\":true,"
      "\"valid\":true,"
      "\"active\":true,"
      "\"status\":\"active\","
      "\"message\":\"OK\","
      "\"reason\":null,"
      "\"expiresAt\":\"2099-12-31T23:59:59.000Z\","
      "\"result\":{\"data\":{\"json\":{"
          "\"success\":true,"
          "\"valid\":true,"
          "\"active\":true,"
          "\"status\":\"active\","
          "\"message\":\"OK\","
          "\"reason\":null,"
          "\"expiresAt\":\"2099-12-31T23:59:59.000Z\""
      "}}}"
    "}";
    return [json dataUsingEncoding:NSUTF8StringEncoding];
}

#pragma mark - NSURLProtocol: sequestra a validacao de chave

@interface KeyBypassURLProtocol : NSURLProtocol @end

@implementation KeyBypassURLProtocol

+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    NSURL *u = request.URL;
    if (!u) return NO;
    NSString *host = u.host.lowercaseString ?: @"";
    NSString *path = u.path ?: @"";
    BOOL match = ([host containsString:@"proxysystem.org"] &&
                  [path containsString:@"proxyKeys.publicCheckKey"]);
    if (match) LOG("canInit -> YES  %@ %@", request.HTTPMethod, u.absoluteString);
    return match;
}

+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }

- (void)startLoading {
    NSURLRequest *req = self.request;
    LOG("INTERCEPT %@ %@", req.HTTPMethod, req.URL.absoluteString);
    if (req.HTTPBody) {
        NSString *b = [[NSString alloc] initWithData:req.HTTPBody encoding:NSUTF8StringEncoding];
        if (b) LOG("  req body: %@", b);
    }
    if (req.allHTTPHeaderFields.count)
        LOG("  req headers: %@", req.allHTTPHeaderFields);

    NSData *payload = FakeCheckPayload();
    NSHTTPURLResponse *resp =
        [[NSHTTPURLResponse alloc] initWithURL:req.URL
                                    statusCode:200
                                   HTTPVersion:@"HTTP/1.1"
                                  headerFields:@{ @"Content-Type": @"application/json" }];
    [self.client URLProtocol:self didReceiveResponse:resp
          cacheStoragePolicy:NSURLCacheStorageNotAllowed];
    [self.client URLProtocol:self didLoadData:payload];
    [self.client URLProtocolDidFinishLoading:self];
}

- (void)stopLoading {}
@end

#pragma mark - Keychain seed

static void SeedKeychain(void) {
    NSDictionary *query = @{
        (__bridge id)kSecClass:       (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: kKeychainService,
        (__bridge id)kSecAttrAccount: kKeychainAccount,
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    NSMutableDictionary *add = [query mutableCopy];
    add[(__bridge id)kSecValueData] = [kFakeKey dataUsingEncoding:NSUTF8StringEncoding];
    add[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleAfterFirstUnlock;
    OSStatus st = SecItemAdd((__bridge CFDictionaryRef)add, NULL);
    LOG("keychain seed status=%d", (int)st);
}

#pragma mark - Forcar estado (so funciona se a classe for @objc-visible)

static char retTrue (id self, SEL _cmd) { return 1; }
static char retFalse(id self, SEL _cmd) { return 0; }
static id   retFuture(id self, SEL _cmd) { return [NSDate distantFuture]; }
static id   retNil   (id self, SEL _cmd) { return nil; }

static void ForceGetter(Class cls, SEL sel, IMP imp) {
    Method m = class_getInstanceMethod(cls, sel);
    if (m) { method_setImplementation(m, imp); LOG("forced %s.%s", class_getName(cls), sel_getName(sel)); }
    else      LOG("missing %s.%s", class_getName(cls), sel_getName(sel));
}

static void DumpIfCandidate(Class cls, const char *name) {
    if (!strstr(name, "IOSKeySession") && !strstr(name, "KeySession")) return;
    LOG("candidate class: %s", name);
    unsigned int n = 0;
    Method *ms = class_copyMethodList(cls, &n);
    for (unsigned int i = 0; i < n; i++)
        LOG("   - %s", sel_getName(method_getName(ms[i])));
    free(ms);
}

static void ForEachObjCClass(void (^blk)(Class, const char *)) {
    unsigned int count = 0;
    Class *cs = objc_copyClassList(&count);
    for (unsigned int i = 0; i < count; i++) blk(cs[i], class_getName(cs[i]));
    free(cs);
}

#pragma mark - Entry

%ctor {
    @autoreleasepool {
        SeedKeychain();
        [NSURLProtocol registerClass:[KeyBypassURLProtocol class]];

        ForEachObjCClass(^(Class cls, const char *name) {
            DumpIfCandidate(cls, name);
            if (strstr(name, "IOSKeySession") || strstr(name, "KeySession")) {
                ForceGetter(cls, @selector(isAuthenticated), (IMP)retTrue);
                ForceGetter(cls, @selector(isChecking),      (IMP)retFalse);
                ForceGetter(cls, @selector(errorMessage),    (IMP)retNil);
                ForceGetter(cls, @selector(expiresAt),       (IMP)retFuture);
            }
        });
        LOG("loaded");
    }
}