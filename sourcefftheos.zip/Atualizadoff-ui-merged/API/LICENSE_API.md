# API de licenças

## Endpoint

`POST https://api-production-182c.up.railway.app/api/license/validate`

O cliente envia `Content-Type: application/json`. Não existe uma API key fixa no cabeçalho; a key de licença é enviada no corpo da requisição.

## Requisição

```json
{
  "key": "SUA_KEY_GERADA_NO_PAINEL",
  "device_id": "ID_UNICO_DO_DISPOSITIVO",
  "package": "com.dts.freefireth",
  "app_version": "1.0.0"
}
```

Os quatro campos são obrigatórios. O `LicenseGate` usa o `identifierForVendor` como identificador estável do dispositivo e mantém a key informada no Keychain do dispositivo.

## Respostas

Uma licença válida retorna HTTP 200 e `valid: true`:

```json
{
  "valid": true,
  "code": "valid",
  "message": "Licença válida"
}
```

Quando a licença é inválida, expirada, revogada, bloqueada ou excede o limite de dispositivos, a API retorna `valid: false`, normalmente com `code: "invalid_key"`. Campos ausentes ou vazios resultam em HTTP 400 com `code: "invalid_request"`. Indisponibilidade temporária do serviço pode resultar em HTTP 503 com `code: "service_unavailable"`.

O menu somente é liberado quando a resposta possui HTTP 200, não há erro de transporte e `valid` é verdadeiro. Em qualquer outro caso, o usuário recebe a mensagem retornada pela API, quando disponível, e pode tentar novamente ou sair.
