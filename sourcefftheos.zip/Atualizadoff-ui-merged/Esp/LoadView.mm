#import "LoadView.h"
#import <UIKit/UIKit.h>
#import <pthread.h>
#import "../LicenseGate.h"
#import "PubgLoad.h"

void *hack_thread(void *) { return NULL; }
static PubgLoad *gMenuLoader = nil;
UIView *menuTouchView = nil;
UIButton *InvisibleMenuButton = nil;
UIButton *VisibleMenuButton = nil;
UITextField *hideRecordTextfield = nil;
UIView *hideRecordView = nil;

static UIWindow *ActiveWindow(void) {
    UIApplication *application = [UIApplication sharedApplication];
    UIWindow *window = application.keyWindow;
    if (window && !window.hidden && window.rootViewController) return window;
    for (UIWindow *candidate in application.windows) {
        if (!candidate.hidden && candidate.alpha > 0.0 && candidate.rootViewController) return candidate;
    }
    return nil;
}

static void StartUIKitInterfaceAfterLicense(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *window = ActiveWindow();
        if (!window) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                StartUIKitInterfaceAfterLicense();
            });
            return;
        }
        [LicenseGate presentForWindow:window success:^{
            dispatch_async(dispatch_get_main_queue(), ^{
                gMenuLoader = [PubgLoad new];
                [gMenuLoader installMenuGestures];
                pthread_t hacks;
                pthread_create(&hacks, NULL, hack_thread, NULL);
            });
        }];
    });
}

static void didFinishLaunching(CFNotificationCenterRef center,
                               void *observer,
                               CFStringRef name,
                               const void *object,
                               CFDictionaryRef info) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        StartUIKitInterfaceAfterLicense();
    });
}

__attribute__((constructor)) static void initialize(void) {
    CFNotificationCenterAddObserver(CFNotificationCenterGetLocalCenter(), NULL, &didFinishLaunching,
                                     (CFStringRef)UIApplicationDidFinishLaunchingNotification, NULL,
                                     CFNotificationSuspensionBehaviorDrop);
}

@implementation MenuLoad
@end
