#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PubgLoad : NSObject
- (void)installMenuGestures;
- (void)openUIKitMenu;
- (void)closeUIKitMenu;
@end

NS_ASSUME_NONNULL_END

