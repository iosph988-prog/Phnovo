#import "PubgLoad.h"
#import <UIKit/UIKit.h>
#import "menuUIKIT/drawview.h"

@interface PubgLoad ()
@property(nonatomic, assign) BOOL gesturesInstalled;
@property(nonatomic, assign) BOOL menuOpen;
@end

@implementation PubgLoad

- (void)installMenuGestures {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self installMenuGestures]; });
        return;
    }
    UIWindow *window = [self activeWindow];
    if (!window || !window.rootViewController || !window.rootViewController.viewIfLoaded.window) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self installMenuGestures];
        });
        return;
    }
    if (!self.gesturesInstalled) {
        UITapGestureRecognizer *openTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openUIKitMenu)];
        openTap.numberOfTapsRequired = 2;
        openTap.numberOfTouchesRequired = 4;
        openTap.cancelsTouchesInView = NO;
        [window addGestureRecognizer:openTap];
        UITapGestureRecognizer *closeTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeUIKitMenu)];
        closeTap.numberOfTapsRequired = 1;
        closeTap.numberOfTouchesRequired = 2;
        closeTap.cancelsTouchesInView = NO;
        [window addGestureRecognizer:closeTap];
        self.gesturesInstalled = YES;
    }
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self openUIKitMenu];
    });
}

- (UIWindow *)activeWindow {
    UIApplication *application = [UIApplication sharedApplication];
    UIWindow *window = application.keyWindow;
    if (window && !window.hidden && window.rootViewController) return window;
    for (UIWindow *candidate in application.windows) {
        if (!candidate.hidden && candidate.alpha > 0.0 && candidate.rootViewController) return candidate;
    }
    return nil;
}

- (UIViewController *)topViewControllerFrom:(UIViewController *)controller {
    if (controller.presentedViewController && !controller.presentedViewController.isBeingDismissed) {
        return [self topViewControllerFrom:controller.presentedViewController];
    }
    if ([controller isKindOfClass:[UINavigationController class]]) {
        UIViewController *visible = [(UINavigationController *)controller visibleViewController];
        return visible ? [self topViewControllerFrom:visible] : controller;
    }
    if ([controller isKindOfClass:[UITabBarController class]]) {
        UIViewController *selected = [(UITabBarController *)controller selectedViewController];
        return selected ? [self topViewControllerFrom:selected] : controller;
    }
    return controller;
}

- (void)openUIKitMenu {
    if (self.menuOpen) return;
    UIWindow *window = [self activeWindow];
    UIViewController *root = window.rootViewController;
    UIViewController *presenter = root ? [self topViewControllerFrom:root] : nil;
    if (!window || !presenter || !presenter.viewIfLoaded.window) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self openUIKitMenu];
        });
        return;
    }
    if ([presenter isKindOfClass:[ModMenuViewController class]]) {
        self.menuOpen = YES;
        return;
    }
    ModMenuViewController *menuVC = [[ModMenuViewController alloc] init];
    menuVC.modalPresentationStyle = UIModalPresentationOverFullScreen;
    [presenter presentViewController:menuVC animated:NO completion:^{ self.menuOpen = YES; }];
}

- (void)closeUIKitMenu {
    if (!self.menuOpen) return;
    UIWindow *window = [self activeWindow];
    UIViewController *root = window.rootViewController;
    UIViewController *presenter = root ? [self topViewControllerFrom:root] : nil;
    if ([presenter isKindOfClass:[ModMenuViewController class]]) {
        [presenter dismissViewControllerAnimated:NO completion:^{ self.menuOpen = NO; }];
    } else {
        self.menuOpen = NO;
    }
}

@end
