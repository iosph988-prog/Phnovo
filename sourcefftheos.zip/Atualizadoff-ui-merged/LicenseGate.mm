#import "LicenseGate.h"
#import <Security/Security.h>

// Contrato da API documentado em APIdelicençasekeys.pdf.
static NSString * const kLicenseKeychainService = @"com.easycheats.ffh4x.license";
static NSString * const kLicenseEndpoint = @"https://api-production-182c.up.railway.app/api/license/validate";
static NSString * const kLicensePackage = @"com.dts.freefireth";
static NSString * const kLicenseVersion = @"1.0.0";

@implementation LicenseGate

+ (NSString *)storedKey {
    NSDictionary *query = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService: kLicenseKeychainService,
                            (__bridge id)kSecReturnData: @YES,
                            (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne};
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status != errSecSuccess || !result) return nil;
    NSData *data = CFBridgingRelease(result);
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

+ (void)storeKey:(NSString *)key {
    NSData *data = [key dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *query = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService: kLicenseKeychainService};
    SecItemDelete((__bridge CFDictionaryRef)query);
    NSDictionary *item = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
                           (__bridge id)kSecAttrService: kLicenseKeychainService,
                           (__bridge id)kSecValueData: data,
                           (__bridge id)kSecAttrAccessible: (__bridge id)kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly};
    SecItemAdd((__bridge CFDictionaryRef)item, NULL);
}

+ (NSString *)deviceIdentifier {
    NSString *value = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    return value.length ? value : [[NSUUID UUID] UUIDString];
}

+ (void)presentForWindow:(UIWindow *)window success:(dispatch_block_t)success {
    if (!window) return;
    NSString *stored = [self storedKey];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Licença necessária" message:@"Digite sua key para continuar." preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.placeholder = @"NX-...";
        field.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.text = stored;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    __weak UIAlertController *weakAlert = alert;
    [alert addAction:[UIAlertAction actionWithTitle:@"Validar" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *key = [weakAlert.textFields.firstObject.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if (!key.length) { [self presentForWindow:window success:success]; return; }
        [self validate:key window:window success:success];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Sair" style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) { exit(0); }]];
    UIViewController *presenter = window.rootViewController;
    while (presenter.presentedViewController) presenter = presenter.presentedViewController;
    [presenter presentViewController:alert animated:YES completion:nil];
}

+ (void)validate:(NSString *)key window:(UIWindow *)window success:(dispatch_block_t)success {
    NSURL *url = [NSURL URLWithString:kLicenseEndpoint];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15.0];
    request.HTTPMethod = @"POST";
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    NSDictionary *payload = @{ @"key": key, @"device_id": [self deviceIdentifier], @"package": kLicensePackage, @"app_version": kLicenseVersion };
    request.HTTPBody = [NSJSONSerialization dataWithJSONObject:payload options:0 error:nil];
    UIAlertController *loading = [UIAlertController alertControllerWithTitle:@"Validando" message:@"Aguarde..." preferredStyle:UIAlertControllerStyleAlert];
    UIViewController *presenter = window.rootViewController;
    while (presenter.presentedViewController) presenter = presenter.presentedViewController;
    [presenter presentViewController:loading animated:YES completion:nil];
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [loading dismissViewControllerAnimated:YES completion:^{
                NSDictionary *json = nil;
                if (data) {
                    id object = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
                    if ([object isKindOfClass:[NSDictionary class]]) json = object;
                }
                BOOL valid = [json[@"valid"] isKindOfClass:[NSNumber class]] && [json[@"valid"] boolValue];
                BOOL httpOK = [response isKindOfClass:[NSHTTPURLResponse class]] && ((NSHTTPURLResponse *)response).statusCode == 200;
                if (!error && httpOK && valid) {
                    [self storeKey:key];
                    if (success) success();
                } else {
                    NSString *serverMessage = [json[@"message"] isKindOfClass:[NSString class]] ? json[@"message"] : nil;
                    NSString *message = serverMessage.length ? serverMessage : @"A key inválida, expirada ou sem conexão não libera o menu.";
                    UIAlertController *failure = [UIAlertController alertControllerWithTitle:@"Key recusada" message:message preferredStyle:UIAlertControllerStyleAlert];
                    [failure addAction:[UIAlertAction actionWithTitle:@"Tentar novamente" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [self presentForWindow:window success:success]; }]];
                    [failure addAction:[UIAlertAction actionWithTitle:@"Sair" style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) { exit(0); }]];
                    [presenter presentViewController:failure animated:YES completion:nil];
                }
            }];
        });
    }] resume];
}

@end
