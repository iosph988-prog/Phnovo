#import <UIKit/UIKit.h>
@interface MenuLoad : NSObject
@end

