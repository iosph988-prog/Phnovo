#import <UIKit/UIKit.h>

@interface MenuInteraction : UIView
@end

@interface MenuLoad : NSObject
@end

