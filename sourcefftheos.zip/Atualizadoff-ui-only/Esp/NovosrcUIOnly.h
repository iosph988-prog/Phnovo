#import <UIKit/UIKit.h>

@interface NovosrcUIOnly : NSObject
+ (instancetype)shared;
- (void)install;
- (void)openMenu;
- (void)closeMenu;
@end

