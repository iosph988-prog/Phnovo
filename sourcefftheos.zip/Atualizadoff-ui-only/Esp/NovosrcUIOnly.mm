#import "NovosrcUIOnly.h"
#import <UIKit/UIKit.h>

@interface NovosrcPanelController : UIViewController
@end

static UIColor *NRed(void) { return [UIColor colorWithRed:0.96 green:0.18 blue:0.25 alpha:1.0]; }
static UIColor *NBackground(void) { return [UIColor colorWithRed:0.035 green:0.04 blue:0.06 alpha:0.98]; }
static UIColor *NSurface(void) { return [UIColor colorWithRed:0.075 green:0.085 blue:0.11 alpha:1.0]; }

@interface NovosrcUIOnly ()
@property(nonatomic, strong) NovosrcPanelController *controller;
@property(nonatomic, assign) BOOL installed;
@end

@implementation NovosrcUIOnly

+ (instancetype)shared {
    static NovosrcUIOnly *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ instance = [NovosrcUIOnly new]; });
    return instance;
}

- (UIWindow *)activeWindow {
    UIApplication *app = UIApplication.sharedApplication;
    if (app.keyWindow && !app.keyWindow.hidden) return app.keyWindow;
    for (UIWindow *window in app.windows) {
        if (!window.hidden && window.rootViewController) return window;
    }
    return nil;
}

- (void)install {
    if (self.installed) return;
    self.installed = YES;
    UIWindow *window = [self activeWindow];
    if (!window) {
        self.installed = NO;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self install]; });
        return;
    }
    UITapGestureRecognizer *open = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openMenu)];
    open.numberOfTapsRequired = 2;
    open.numberOfTouchesRequired = 4;
    open.cancelsTouchesInView = NO;
    [window addGestureRecognizer:open];
    UITapGestureRecognizer *close = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeMenu)];
    close.numberOfTapsRequired = 1;
    close.numberOfTouchesRequired = 2;
    close.cancelsTouchesInView = NO;
    [window addGestureRecognizer:close];
}

- (UIViewController *)topController:(UIViewController *)controller {
    if (controller.presentedViewController && !controller.presentedViewController.isBeingDismissed) return [self topController:controller.presentedViewController];
    if ([controller isKindOfClass:UINavigationController.class]) return [self topController:[(UINavigationController *)controller visibleViewController]];
    if ([controller isKindOfClass:UITabBarController.class]) return [self topController:[(UITabBarController *)controller selectedViewController]];
    return controller;
}

- (void)openMenu {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *window = [self activeWindow];
        UIViewController *top = window.rootViewController ? [self topController:window.rootViewController] : nil;
        if (!top || [top isKindOfClass:NovosrcPanelController.class]) return;
        self.controller = [NovosrcPanelController new];
        self.controller.modalPresentationStyle = UIModalPresentationOverFullScreen;
        [top presentViewController:self.controller animated:NO completion:nil];
    });
}

- (void)closeMenu {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.controller.presentingViewController) [self.controller dismissViewControllerAnimated:NO completion:nil];
        self.controller = nil;
    });
}

@end

@interface NovosrcPanelController ()
@property(nonatomic, strong) UIView *panel;
@property(nonatomic, strong) UIView *content;
@property(nonatomic, strong) UILabel *titleLabel;
@property(nonatomic, strong) NSArray<UIButton *> *tabButtons;
@property(nonatomic, assign) NSInteger selectedTab;
@end

@implementation NovosrcPanelController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.18];
    self.view.multipleTouchEnabled = YES;
    [self buildInterface];
}

- (void)buildInterface {
    CGFloat width = MIN(UIScreen.mainScreen.bounds.size.width - 28.0, 430.0);
    CGFloat height = MIN(UIScreen.mainScreen.bounds.size.height - 70.0, 620.0);
    self.panel = [[UIView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-width)/2.0, (self.view.bounds.size.height-height)/2.0, width, height)];
    self.panel.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    self.panel.backgroundColor = NBackground();
    self.panel.layer.cornerRadius = 18.0;
    self.panel.layer.borderWidth = 1.0;
    self.panel.layer.borderColor = [NRed() colorWithAlphaComponent:0.75].CGColor;
    self.panel.layer.shadowColor = UIColor.blackColor.CGColor;
    self.panel.layer.shadowOpacity = 0.45;
    self.panel.layer.shadowRadius = 18.0;
    [self.view addSubview:self.panel];

    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 17, width-70, 30)];
    self.titleLabel.text = @"EASYCHEATS  •  NOVOSRC UI";
    self.titleLabel.textColor = UIColor.whiteColor;
    self.titleLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightBold];
    [self.panel addSubview:self.titleLabel];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.frame = CGRectMake(width-48, 12, 34, 34);
    [close setTitle:@"×" forState:UIControlStateNormal];
    [close setTitleColor:NRed() forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:28 weight:UIFontWeightMedium];
    [close addTarget:self action:@selector(closePressed) forControlEvents:UIControlEventTouchUpInside];
    [self.panel addSubview:close];

    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(18, 56, width-36, 1)];
    line.backgroundColor = [NRed() colorWithAlphaComponent:0.45];
    [self.panel addSubview:line];

    NSArray *names = @[@"AIM", @"ESP", @"MISC", @"INFO"];
    NSMutableArray *buttons = [NSMutableArray array];
    CGFloat tabWidth = (width-36)/names.count;
    for (NSInteger i=0; i<names.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.frame = CGRectMake(18+i*tabWidth, 70, tabWidth, 36);
        button.tag = i;
        [button setTitle:names[i] forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightBold];
        [button addTarget:self action:@selector(tabPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self.panel addSubview:button];
        [buttons addObject:button];
    }
    self.tabButtons = buttons;
    self.content = [[UIView alloc] initWithFrame:CGRectMake(18, 115, width-36, height-133)];
    [self.panel addSubview:self.content];
    [self renderTab:0];
}

- (void)tabPressed:(UIButton *)sender { [self renderTab:sender.tag]; }

- (void)renderTab:(NSInteger)tab {
    self.selectedTab = tab;
    for (UIButton *button in self.tabButtons) [button setTitleColor:(button.tag == tab ? NRed() : [UIColor colorWithWhite:0.58 alpha:1]) forState:UIControlStateNormal];
    [self.content.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    NSArray *titles = @[@"Aimbot", @"Visual", @"Movement & Tools", @"Build Information"];
    UILabel *section = [[UILabel alloc] initWithFrame:CGRectMake(4, 4, self.content.bounds.size.width-8, 28)];
    section.text = titles[tab]; section.textColor = UIColor.whiteColor; section.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    [self.content addSubview:section];
    NSArray *items = tab == 0 ? @[@"Enable Aimbot", @"Silent Aim", @"Aim FOV", @"Target Priority"] : tab == 1 ? @[@"ESP", @"Boxes", @"Lines", @"Skeleton", @"Names"] : tab == 2 ? @[@"Speed", @"High FPS", @"No Recoil", @"Stream Protection"] : @[@"Interface: Novosrc", @"License: API validation", @"Architecture: arm64"];
    CGFloat y = 46;
    for (NSString *name in items) {
        UIView *row = [[UIView alloc] initWithFrame:CGRectMake(0, y, self.content.bounds.size.width, 44)];
        row.backgroundColor = NSurface(); row.layer.cornerRadius = 10;
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(14, 0, row.bounds.size.width-88, 44)];
        label.text = name; label.textColor = [UIColor colorWithWhite:0.92 alpha:1]; label.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
        [row addSubview:label];
        if (tab < 3) {
            UISwitch *toggle = [[UISwitch alloc] initWithFrame:CGRectZero]; toggle.onTintColor = NRed(); toggle.transform = CGAffineTransformMakeScale(0.78, 0.78); toggle.center = CGPointMake(row.bounds.size.width-34, 22); [row addSubview:toggle];
        } else {
            UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(row.bounds.size.width-28, 16, 12, 12)]; dot.backgroundColor = NRed(); dot.layer.cornerRadius = 6; [row addSubview:dot];
        }
        [self.content addSubview:row]; y += 52;
    }
}

- (void)closePressed { [self dismissViewControllerAnimated:NO completion:nil]; }
@end
