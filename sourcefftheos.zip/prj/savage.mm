#import "Esp/ImGuiDrawView.h"
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#define ICON_FA_COG u8"\uf013"
#define ICON_FA_EXTRA u8"\uf067"
#define ICON_FA_EXCLAMATION_TRIANGLE "\xef\x81\xb1"
#define ICON_FA_EXCLAMATION_TRIANGLE u8"\uf071"
#include <iostream>
#include <UIKit/UIKit.h>
#include <vector>
#include "iconcpp.h"
#import "pthread.h"
#include <array>
#include <cmath>
#include <deque>
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdint>
#include <cerrno>
#include <cctype>
// Imgui library
#import "API/APIClient.h"
#import "JRMemory.framework/Headers/MemScan.h"
#import "Esp/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_internal.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/zzz.h"
#include "oxorany/oxorany_include.h"
#import "Helper/Mem.h"
#include "font.h"
#import "Esp/Includes.h"
#import "Helper/Vector3.h"
#import "Helper/Vector2.h"
#import "Helper/Quaternion.h"
#import "Helper/Monostring.h"
#import <Foundation/Foundation.h>
#include "Helper/font.h"
#include "Helper/data.h"
#include "ban.cpp"
ImFont* verdana_smol;
ImFont* pixel_big = {};
ImFont* pixel_smol = {};
#include "Helper/Obfuscate.h"
#import "Helper/Hooks.h"
#import "IMGUI/zzz.h"
#include <OpenGLES/ES2/gl.h>
#include <OpenGLES/ES2/glext.h>
#include <unistd.h>
#include <string.h>
#include "hook/hook.h"
ImVec4 userColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 espv = ImVec4(0.0f, 1.0f, 0.0f, 1.0f);
ImVec4 espi = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 fovColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
ImVec4 nameColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
ImVec4 distanceColor = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define UIColorFromHex(hexColor) [UIColor colorWithRed:((float)((hexColor & 0xFF0000) >> 16))/255.0 green:((float)((hexColor & 0xFF00) >> 8))/255.0 blue:((float)(hexColor & 0xFF))/255.0 alpha:1.0]
UIWindow *mainWindow;
UIButton *menuView;
// Ghost Mode Variables


@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@property (nonatomic, strong) UIButton *ghostButtonView;
@property (nonatomic, strong) UISwitch *ghostSwitch;
@end


@implementation ImGuiDrawView
ImFont *_espFont;
ImFont* verdanab;
ImFont* icons;
ImFont* interb;
ImFont* Urbanist;

static bool MenDeal = true;
BOOL hasGhostBeenDrawn = NO;
static bool StreamerMode = true;
static bool aimKill = false;
static bool voarPlayer = false;
static bool teleport8m = false;
bool fakeLagEnabled = false;
bool FastReloadEnabled = true;
bool SpeeeX2Enabled = false;
bool NoRecoilEnabled = false;
bool WallGlowEnabled = false;
bool WallFlyEnabled = false;
bool WallHackEnabled = false;
bool ScopeEnabled = false;
bool BypassEnabled = true;
bool istelekill = false;
bool func_ghost = false;
bool isfly = false;
bool antiban(void *instance) {
    return false;
}
int FUNC_GHOST(void *instance) {
    return 31278;
}
- (void)ghostModeUI {
    if (self.ghostButtonView) return;

    self.ghostButtonView = [[UIButton alloc] initWithFrame:CGRectMake(305, 330, 58, 54)];
    self.ghostButtonView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.2];
    self.ghostButtonView.layer.cornerRadius = 13;
    self.ghostButtonView.clipsToBounds = YES;
    self.ghostButtonView.layer.shadowOpacity = 0;
    self.ghostButtonView.layer.shadowColor = [UIColor clearColor].CGColor;
    self.ghostButtonView.layer.shadowRadius = 0;
    self.ghostButtonView.alpha = 1.0f;

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 1, 58, 20)];
    label.text = @"Ghost";
    label.font = [UIFont fontWithName:@"CourierNewPS-BoldMT" size:11];
    label.textColor = [UIColor blackColor];
    label.backgroundColor = [UIColor clearColor];
    [self.ghostButtonView addSubview:label];

    self.ghostSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(3.5, 20, 51, 31)];
    self.ghostSwitch.onTintColor = [UIColor purpleColor];
    self.ghostSwitch.thumbTintColor = [UIColor whiteColor];
    self.ghostSwitch.backgroundColor = [UIColor clearColor];
    [self.ghostSwitch addTarget:self action:@selector(ghostSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [self.ghostButtonView addSubview:self.ghostSwitch];

    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleGhostDrag:)];
    [self.ghostButtonView addGestureRecognizer:panGesture];

    UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;
    [mainWindow addSubview:self.ghostButtonView];
}

- (void)ghostSwitchChanged:(UISwitch *)sender {
    Vars.EnableGhost = sender.on;
    static bool ghostState = false;
    void* ghostMain = (void*)getRealOffset(ENCRYPTOFFSET("0x105C0DC8C"));    // main ghost effect

    if (sender.on && !ghostState) {
        hook((void*[]){ ghostMain },
             (void*[]){ (void*)FUNC_GHOST },
             1);
        func_ghost = true;
        ghostState = true;
    } else if (!sender.on && ghostState) {
         Unhook(ghostMain);
           func_ghost = false;
        ghostState = false;
    }
}

- (void)handleGhostDrag:(UIPanGestureRecognizer *)gesture {
    UIView *draggedView = gesture.view;
    CGPoint translation = [gesture translationInView:draggedView.superview];
    CGPoint newCenter = CGPointMake(draggedView.center.x + translation.x, draggedView.center.y + translation.y);
    draggedView.center = newCenter;
    [gesture setTranslation:CGPointZero inView:draggedView.superview];
}

- (void)toggleSpeedX2:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x200000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            uint64_t search = 4397530849764387586;
            engine->JRScanMemory(range, &search, JR_Search_Type_ULong);
            results = engine->getAllResults();
        });
        
        uint64_t modify = 4366458311853765201;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
    } else {
        uint64_t modify = 4397530849764387586; // Original value
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (void)toggleNoRecoil:(BOOL)enable {
    static dispatch_once_t onceToken;
    static std::vector<void*> results; 

    JRMemoryEngine* engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = { 0x100000000, 0x200000000 }; 

    if (enable) {
        dispatch_once(&onceToken, ^{
            uint64_t search = 1016018816; 
            engine->result->resultBuffer.clear();
            engine->result->count = 0;
            engine->JRScanMemory(range, &search, JR_Search_Type_ULong);
            results = engine->getAllResults();
        });

        uint64_t modify = 0; 
        for (size_t i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
    } else {
        uint64_t modify = 1016018816; 
        for (size_t i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_ULong);
        }
        onceToken = 0; 
        results.clear();
    }

    delete engine;
}

- (void)toggleWallGlow:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 1.22f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
        });

        
        float modify = 965.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 1.22f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}



- (void)toggleWallFly:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 1.5f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
        });
        
        float modify = 900.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 1.5f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (void)toggleWallHack:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 2;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            float search1 = 0.10000000149;
            engine->JRNearBySearch(0x20, &search1, JR_Search_Type_Float);
            float search2 = 3;
            engine->JRScanMemory(range, &search2, JR_Search_Type_Float);
            float search3 = 4.2038954e-45;
            engine->JRScanMemory(range, &search3, JR_Search_Type_Float);
            float search4 = 4.2038954e-45;
            engine->JRNearBySearch(0x20, &search4, JR_Search_Type_Float);
            results = engine->getAllResults();
        });
        
        float modify = -99;
        float modify1 = -1;
        float modify2 = -999;
        float modify3 = 1.3998972e-42;
        float modify4 = 1.3998972e-42;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        // Note: Original values not provided in the original code
        // You would need to restore the original values here
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (void)toggleScope:(BOOL)enable {
    static dispatch_once_t onceToken;
    static vector<void*> results;
    
    JRMemoryEngine *engine = new JRMemoryEngine(mach_task_self());
    AddrRange range = {0x100000000, 0x160000000};
    
    if (enable) {
        dispatch_once(&onceToken, ^{
            float search = 0.03f;
            engine->JRScanMemory(range, &search, JR_Search_Type_Float);
            results = engine->getAllResults();
        });
        
        float modify = 10.0f;
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
    } else {
        float modify = 0.03f; // Original value
        for(int i = 0; i < results.size(); i++) {
            engine->JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
        }
        onceToken = 0;
        results.clear();
    }
    delete engine;
}

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
   ImGuiStyle& style = ImGui::GetStyle();

// ================= TEXTO =================
style.Colors[ImGuiCol_Text] = ImVec4(1.00f, 1.00f, 1.00f, 1.00f); // Branco sólido

// ================= FUNDOS =================
style.Colors[ImGuiCol_WindowBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.85f);  // Janela
style.Colors[ImGuiCol_ChildBg]  = ImVec4(0.00f, 0.00f, 0.00f, 0.85f);  // Child
style.Colors[ImGuiCol_PopupBg]  = ImVec4(0.05f, 0.05f, 0.05f, 0.90f);  // Popups

// ================= BORDAS =================
style.Colors[ImGuiCol_Border] = ImVec4(0.20f, 0.20f, 0.20f, 0.30f); // Quase invisível

// ================= CHECKBOX =================
// Desmarcado: cinza escuro
style.Colors[ImGuiCol_FrameBg]        = ImVec4(0.15f, 0.15f, 0.15f, 0.90f);
// Hover (mouse em cima)
style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
// Ativo (marcado): vermelho sólido
style.Colors[ImGuiCol_FrameBgActive]  = ImVec4(0.86f, 0.16f, 0.16f, 1.00f);
// ✔️ invisível
style.Colors[ImGuiCol_CheckMark]      = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);

// ================= TÍTULO =================
style.Colors[ImGuiCol_TitleBg]       = ImVec4(0.86f, 0.16f, 0.16f, 1.00f);
style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.86f, 0.16f, 0.16f, 1.00f);

// ================= BOTÕES =================
style.Colors[ImGuiCol_Button]        = ImVec4(0.86f, 0.16f, 0.16f, 1.00f); // Normal
style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.95f, 0.25f, 0.25f, 1.00f); // Hover
style.Colors[ImGuiCol_ButtonActive]  = ImVec4(0.70f, 0.08f, 0.08f, 1.00f); // Pressionado

// ================= RESIZE GRIP & SEPARADORES =================
style.Colors[ImGuiCol_Separator]          = ImVec4(0.30f, 0.30f, 0.30f, 0.60f);
style.Colors[ImGuiCol_ResizeGrip]         = ImVec4(0.30f, 0.30f, 0.30f, 0.40f);
style.Colors[ImGuiCol_ResizeGripHovered]  = ImVec4(0.40f, 0.40f, 0.40f, 0.70f);
style.Colors[ImGuiCol_ResizeGripActive]   = ImVec4(0.60f, 0.60f, 0.60f, 0.90f);

// ================= TABS =================
style.Colors[ImGuiCol_Tab]                = ImVec4(0.15f, 0.15f, 0.15f, 0.70f);
style.Colors[ImGuiCol_TabHovered]         = ImVec4(0.86f, 0.16f, 0.16f, 0.90f);
style.Colors[ImGuiCol_TabActive]          = ImVec4(0.86f, 0.16f, 0.16f, 1.00f);
style.Colors[ImGuiCol_TabUnfocused]       = ImVec4(0.10f, 0.10f, 0.10f, 0.50f);
style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.20f, 0.20f, 0.20f, 0.70f);




// ================= ARREDONDAMENTO =================
style.WindowRounding     = 5.0f;
style.ChildRounding      = 5.0f;
style.FrameRounding      = 5.0f;
style.GrabRounding       = 5.0f;
style.PopupRounding      = 5.0f;
style.ScrollbarRounding  = 5.0f;
style.TabRounding        = 5.0f;

// ================= BORDAS =================
style.WindowBorderSize = 5.0f;
style.FrameBorderSize  = 5.0f;
style.PopupBorderSize  = 5.0f;

// ================= ESPAÇAMENTO =================
style.WindowPadding = ImVec2(10.0f, 8.0f);
style.FramePadding  = ImVec2(12.0f, 6.0f);  // Mais alto para melhor visual nos checkboxes
style.ItemSpacing   = ImVec2(6.0f, 3.0f);













    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };
    ImFontConfig icons_config;
    ImFontConfig CustomFont;
    CustomFont.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    io.Fonts->AddFontFromMemoryTTF(const_cast<std::uint8_t*>(Custom), sizeof(Custom), 21.f, &CustomFont);
    io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);
    io.Fonts->AddFontDefault();
    ImFont* font = io.Fonts->AddFontFromMemoryTTF(sansbold, sizeof(sansbold), 21.0f, NULL, io.Fonts->GetGlyphRangesCyrillic());
    verdana_smol = io.Fonts->AddFontFromMemoryTTF(verdana, sizeof verdana, 40, NULL, io.Fonts->GetGlyphRangesCyrillic());
    pixel_big = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 400, NULL, io.Fonts->GetGlyphRangesCyrillic());
    pixel_smol = io.Fonts->AddFontFromMemoryTTF((void*)smallestpixel, sizeof smallestpixel, 10*2, NULL, io.Fonts->GetGlyphRangesCyrillic());
    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open {
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

- (MTKView *)mtkView {
    return (MTKView *)self.view;
}

void SeparatorCustom(float width, float thickness, ImVec4 userColor)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return;

    ImVec2 pos = window->DC.CursorPos;
    float avail_width = ImGui::GetContentRegionAvail().x;

    if (width > avail_width)
        width = avail_width;

    ImGui::Dummy(ImVec2(width, thickness));

    ImU32 col = ImGui::GetColorU32(userColor);

    ImVec2 p1 = pos;
    ImVec2 p2 = ImVec2(pos.x + width, pos.y);

    window->DrawList->AddLine(p1, p2, col, thickness);
}



- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    self.mtkView.clipsToBounds = YES;
}
#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}




// أضف قبل drawInMTKView

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);



    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
        
    hideRecordTextfield.secureTextEntry = StreamerMode;

    if (MenDeal == true) 
    {
        [self.view setUserInteractionEnabled:YES];
        [self.view.superview setUserInteractionEnabled:YES];
        [menuTouchView setUserInteractionEnabled:YES];
    } 
    else if (MenDeal == false) 
    {
        [self.view setUserInteractionEnabled:NO];
        [self.view.superview setUserInteractionEnabled:NO];
        [menuTouchView setUserInteractionEnabled:NO];
    }

    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil) 
    {
        id<MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@"ImGui Jane"];

        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();
        ImGuiStyle& style = ImGui::GetStyle();
        ImFont* font = ImGui::GetFont();
        font->Scale = 16.f / font->FontSize;
        
        CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 360) / 2;
CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 280) / 2;

ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
ImGui::SetNextWindowSize(ImVec2(360, 280), ImGuiCond_FirstUseEver);

if (MenDeal == true)
{
    ImGui::Begin(ENCRYPT("                FFH4X PROXY CHEATS             "), &MenDeal, ImGuiWindowFlags_NoResize);
            
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(9, 4));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(9, 4));

    static int activeTab = 0; // controla qual aba está ativa
    ImGuiStyle& style = ImGui::GetStyle();

    // ================== CONTEÚDO DAS ABAS ==================
    if (activeTab == 0) {
        // ---------------- AIM ----------------
        ImGui::Columns(2, "AimBotColumns", false);
        {
            ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
            if (Vars.Aimbot) style.Colors[ImGuiCol_FrameBg] = userColor;
            ImGui::Checkbox("Ativar Aimbot", &Vars.Aimbot);
            style.Colors[ImGuiCol_FrameBg] = backup;
        }

        {
            ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
            if (Vars.IgnoreKnocked) style.Colors[ImGuiCol_FrameBg] = userColor;
            ImGui::Checkbox("Ignorar Derrubados", &Vars.IgnoreKnocked);
            style.Colors[ImGuiCol_FrameBg] = backup;
        }

        ImGui::NextColumn();

        {
            ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
            if (Vars.VisibleCheck) style.Colors[ImGuiCol_FrameBg] = userColor;
            ImGui::Checkbox("Puxar em Paredes", &Vars.VisibleCheck);
            style.Colors[ImGuiCol_FrameBg] = backup;
        }

        {
            ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
            if (Vars.isAimFov) style.Colors[ImGuiCol_FrameBg] = userColor;
            ImGui::Checkbox(ENCRYPT("Exibir FOV"), &Vars.isAimFov);
            style.Colors[ImGuiCol_FrameBg] = backup;
        }

        ImGui::Columns(1);

        // ================= AIMFOV =================
        ImGui::PushItemWidth(200);

        ImVec4 col_bg   = ImVec4(0.15f, 0.15f, 0.15f, 1.0f);
        ImVec4 col_fill = userColor; // usa cor escolhida

        float sliderMin = 0.0f;
        float sliderMax = 500.0f;

        ImVec2 p0 = ImGui::GetCursorScreenPos();
        ImVec2 p1 = ImVec2(p0.x + 200, p0.y + ImGui::GetFrameHeight());

        ImGui::GetWindowDrawList()->AddRectFilled(p0, p1, ImGui::ColorConvertFloat4ToU32(col_bg), 4.0f);

        float t = (Vars.AimFov - sliderMin) / (sliderMax - sliderMin);
        float filledWidth = (p1.x - p0.x) * t;

        ImGui::GetWindowDrawList()->AddRectFilled(p0, ImVec2(p0.x + filledWidth, p1.y),
            ImGui::ColorConvertFloat4ToU32(col_fill), 4.0f);

        ImGui::SetCursorScreenPos(p0);
        ImGui::InvisibleButton("##AimFov", ImVec2(200, ImGui::GetFrameHeight()));
        if (ImGui::IsItemActive()) {
            float mouseDelta = (ImGui::GetIO().MousePos.x - p0.x) / (p1.x - p0.x);
            Vars.AimFov = sliderMin + (sliderMax - sliderMin) * ImClamp(mouseDelta, 0.0f, 1.0f);
        }

        char buf[32];
        sprintf(buf, "%.1f", Vars.AimFov);
        ImVec2 textSize = ImGui::CalcTextSize(buf);
        ImVec2 textPos  = ImVec2(p0.x + (200 - textSize.x) * 0.5f, p0.y + (ImGui::GetFrameHeight() - textSize.y) * 0.5f);
        ImGui::GetWindowDrawList()->AddText(textPos, IM_COL32(255, 255, 255, 255), buf);

        ImGui::SameLine();
        ImGui::Text("Regular FOV");

        ImGui::PopItemWidth();

        // ================= HITBOX =================
        ImGui::PushItemWidth(200);
        ImGui::Combo("##aimhitbox", &Vars.AimHitbox, Vars.aimHitboxes, 3); // ID escondido, sem ícone
        ImGui::SameLine();
        ImGui::Text("Puxada");
        ImGui::PopItemWidth();


        ImGui::Spacing();
        ImGui::Text("Tipo de Aimbot:");
        static int selected_aimbot_type = 1;

        {
            ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
            if (selected_aimbot_type == 0) style.Colors[ImGuiCol_FrameBg] = userColor;
            if (ImGui::RadioButton("Ao Atirar", selected_aimbot_type == 0)) {
                selected_aimbot_type = 0;
                Vars.AimWhen = 1;
            }
            style.Colors[ImGuiCol_FrameBg] = backup;
        }

        ImGui::SameLine();

        {
            ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
            if (selected_aimbot_type == 1) style.Colors[ImGuiCol_FrameBg] = userColor;
            if (ImGui::RadioButton("Ao Olhar", selected_aimbot_type == 1)) {
                selected_aimbot_type = 1;
                Vars.AimWhen = 0;
            }
            style.Colors[ImGuiCol_FrameBg] = backup;
        }
    }
    else if (activeTab == 1) {
       // ---------------- ESP ----------------
ImGui::Columns(2, "ESPColumns", false);

{
    ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
    if (Vars.Enable) style.Colors[ImGuiCol_FrameBg] = userColor;
    ImGui::Checkbox("Ativar ESP", &Vars.Enable);
    style.Colors[ImGuiCol_FrameBg] = backup;
}

ImGui::NextColumn();

{
    ImVec4 backup = style.Colors[ImGuiCol_FrameBg];
    if (StreamerMode) style.Colors[ImGuiCol_FrameBg] = userColor;
    ImGui::Checkbox("Esconder Painel", &StreamerMode);
    style.Colors[ImGuiCol_FrameBg] = backup;
}

ImGui::Columns(1);

// ---------------- ESP Opções ----------------
{
    ImVec4 backup = style.Colors[ImGuiCol_FrameBg];

    // ---------------- ESP Linha ----------------
if (Vars.lines) style.Colors[ImGuiCol_FrameBg] = userColor;
ImGui::Checkbox(ENCRYPT("ESP Linha"), &Vars.lines);
style.Colors[ImGuiCol_FrameBg] = backup;

if (Vars.lines)
{
    ImGui::SameLine(150); // distância fixa do início da janela
    ImGui::Text("Estilo:");
    ImGui::SameLine();
    const char* opcoes[] = { "Cima", "Meio", "Baixo" }; // <--- adicionei "Meio"
    ImGui::SetNextItemWidth(90.0f);
    ImGui::Combo("##LineStyle", &Vars.LineStyle, opcoes, IM_ARRAYSIZE(opcoes));

    // Garantir valor válido (opcional, por segurança)
    if (Vars.LineStyle < 0) Vars.LineStyle = 0;
    if (Vars.LineStyle > 2) Vars.LineStyle = 2;
}

    // ---------------- ESP Caixa ----------------
    if (Vars.Box) style.Colors[ImGuiCol_FrameBg] = userColor;
    ImGui::Checkbox(ENCRYPT("ESP Caixa"), &Vars.Box);
    style.Colors[ImGuiCol_FrameBg] = backup;

    if (Vars.Box)
    {
        ImGui::SameLine(150);
        ImGui::Text("Estilo:");
        ImGui::SameLine();
        const char* estilos[] = { "Normal", "Cornered", "Redondo" };
        ImGui::SetNextItemWidth(115.0f);
        ImGui::Combo("##BoxStyle", &Vars.BoxStyle, estilos, IM_ARRAYSIZE(estilos));
    }

    // ---------------- ESP Nome ----------------
    if (Vars.Name) style.Colors[ImGuiCol_FrameBg] = userColor;
    ImGui::Checkbox(ENCRYPT("ESP Nome"), &Vars.Name);
    style.Colors[ImGuiCol_FrameBg] = backup;

    if (Vars.Name)
    {
        ImGui::SameLine(150);
        ImGui::Text("Estilo:");
        ImGui::SameLine();
        const char* opcoesNome[] = { "Sem Sombra", "Com Sombra" };
        ImGui::SetNextItemWidth(125.0f);
        ImGui::Combo("##NameStyle", &Vars.NameStyle, opcoesNome, IM_ARRAYSIZE(opcoesNome));
    }

    // ---------------- ESP Vida ----------------
    if (Vars.Health) style.Colors[ImGuiCol_FrameBg] = userColor;
    ImGui::Checkbox(ENCRYPT("ESP Vida"), &Vars.Health);
    style.Colors[ImGuiCol_FrameBg] = backup;

    if (Vars.Health)
    {
        ImGui::SameLine(150);
        ImGui::Text("Posição:");
        ImGui::SameLine();
        const char* posicoes[] = { "Esquerda", "Direita" };
        ImGui::SetNextItemWidth(115.0f);
        ImGui::Combo("##HealthPos", &Vars.HealthPos, posicoes, IM_ARRAYSIZE(posicoes));
    }

    // ---------------- ESP Esqueleto ----------------
    if (Vars.skeleton) style.Colors[ImGuiCol_FrameBg] = userColor;
    ImGui::Checkbox(ENCRYPT("ESP Esqueleto"), &Vars.skeleton);
    style.Colors[ImGuiCol_FrameBg] = backup;
}




    }
    else if (activeTab == 2) {
        // ---------------- MISC ----------------
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 0.0f, 1.0f), ICON_FA_EXCLAMATION_TRIANGLE);
        ImGui::SameLine();
    ImGui::Text("Funções Rage");


// checkboxes de cima (AimKill, Troca Arma, Voar)
ImGui::Checkbox("AimKill", &AimKill);
ImGui::SameLine();
ImGui::Checkbox("Troca Arma", &autochangeweapon);
ImGui::SameLine();
ImGui::Checkbox("Voar Player", &Vars.UpPlayerOne);

// Speed -> No Recoil -> Ghost Hack (todos na mesma linha)
if (ImGui::Checkbox(ENCRYPT("Speed"), &SpeeeX2Enabled)) {
    [self toggleSpeedX2:SpeeeX2Enabled];
}
ImGui::SameLine(0, 8.0f); // pequeno espaço entre os botões

if (ImGui::Checkbox(ENCRYPT("No Recoil"), &NoRecoilEnabled)) {
    [self toggleNoRecoil:NoRecoilEnabled];
}
ImGui::SameLine(0, 8.0f); // espaçamento entre No Recoil e Ghost Hack

if (ImGui::Checkbox("Ghost Hack", &Vars.ShowGhostButton)) {
    // opcional: ação ao clicar
}

// ---- lógica de criação/remoção da ghostButtonView ----
if (Vars.ShowGhostButton) {
    if (!self.ghostButtonView) {
        [self ghostModeUI];
    }
} else {
    if (self.ghostButtonView) {
        [self.ghostButtonView removeFromSuperview];
        self.ghostButtonView = nil;
    }
}

        // ===== Personalização - abaixo =====
    ImGui::TextColored(ImVec4(0, 1, 0, 1), ICON_FA_BARS);
    ImGui::SameLine();
    ImGui::Text(ENCRYPT(" Personalização"));

    ImGui::PushItemWidth(40.0f);

    ImGui::ColorEdit4(ENCRYPT("Cor do Painel            "), (float*)&userColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);
    ImGui::SameLine(); 
    ImGui::ColorEdit4(ENCRYPT("Cor do Nome             "), (float*)&nameColor, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);
    ImGui::ColorEdit4(ENCRYPT("Cor da ESP Visível   "), (float*)&espv, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);
    ImGui::SameLine(); 
    ImGui::ColorEdit4(ENCRYPT("Cor da ESP Invisível"), (float*)&espi, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_PickerHueBar);
 
    ImGui::PopItemWidth();

    // Aplicando cor do usuário no style
    ImGuiStyle& style = ImGui::GetStyle();

    style.Colors[ImGuiCol_CheckMark] = ImVec4(0, 0, 0, 0); // totalmente transparente
    style.Colors[ImGuiCol_SliderGrab]       = userColor;
    style.Colors[ImGuiCol_SliderGrabActive] = userColor;

    style.Colors[ImGuiCol_TitleBg]          = userColor;
    style.Colors[ImGuiCol_TitleBgActive]    = userColor;
    style.Colors[ImGuiCol_TitleBgCollapsed] = userColor;
    style.Colors[ImGuiCol_Separator]        = userColor;

    style.Colors[ImGuiCol_Button]           = userColor;
    style.Colors[ImGuiCol_ButtonHovered]    = userColor;
    style.Colors[ImGuiCol_ButtonActive]     = userColor;

    style.Colors[ImGuiCol_Tab]              = userColor;
    style.Colors[ImGuiCol_TabHovered]       = userColor;
    style.Colors[ImGuiCol_TabActive]        = userColor;
    style.Colors[ImGuiCol_TabUnfocusedActive] = userColor;

    style.Colors[ImGuiCol_Header]           = userColor;
    style.Colors[ImGuiCol_HeaderHovered]    = userColor;
    style.Colors[ImGuiCol_HeaderActive]     = userColor;

    style.Colors[ImGuiCol_NavHighlight]     = userColor;
    style.Colors[ImGuiCol_TextSelectedBg]   = userColor;
    style.Colors[ImGuiCol_ScrollbarBg]      = userColor;
    style.Colors[ImGuiCol_ScrollbarGrab]    = userColor;
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = userColor;
    style.Colors[ImGuiCol_ScrollbarGrabActive]  = userColor;


    if (ImGui::Button(ENCRYPT(" Fix Login "))) {
        self.mtkView.hidden = YES;
        MenDeal = NO;
        timer(30) {
            self.mtkView.hidden = NO;
            MenDeal = YES;
        });
    }
}
    else if (activeTab == 3) {
    APIClient *API = [APIClient sharedAPIClient];

    NSString *key         = [API getKey];
    NSString *expiryDate  = [API getExpiryDate];
    NSString *deviceModel = [API getDeviceModel];
    NSString *iosVersion  = [[UIDevice currentDevice] systemVersion];

    // Formatar datas
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"pt"];
    [formatter setDateFormat:@"dd/MM/yyyy HH:mm:ss"];
    NSDate *formatDate = [formatter dateFromString:expiryDate];

    // ExibiÃÂÃÂ§ÃÂÃÂ£o no ImGui
    ImGui::Text("Dispositivo: %s", [deviceModel UTF8String]);
    ImGui::Text("Versao do iOS: %s", [iosVersion UTF8String]);
    ImGui::Text("Expira em: %s", [expiryDate UTF8String]);
    ImGui::Text("Key: %s", [key UTF8String]);
    ImGui::Text("Desenvolvedor:PH IOS");
    ImGui::Separator();
    ImGui::Spacing();
    if (ImGui::Button("off")) {
        NSURL *url = [NSURL URLWithString:@"......"];
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }
}


    // ================== BOTÕES DAS ABAS ==================
float buttonWidth  = 50.0f;
float buttonHeight = 50.0f;
float spacing      = 3.0f; // deixa eles mais juntinhos
float totalWidth   = (buttonWidth * 4) + (spacing * 3);
float startX       = (ImGui::GetWindowWidth() - totalWidth) / 2;

ImGui::SetCursorPosY(ImGui::GetWindowHeight() - (buttonHeight + 10)); 
ImGui::SetCursorPosX(startX);

// aplica espaçamento menor
ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(spacing, 0));

if (ImGui::Button(ICON_FA_CROSSHAIRS, ImVec2(buttonWidth, buttonHeight))) activeTab = 0;
ImGui::SameLine();
if (ImGui::Button(ICON_FA_EYE, ImVec2(buttonWidth, buttonHeight))) activeTab = 1;
ImGui::SameLine();
if (ImGui::Button(ICON_FA_COG, ImVec2(buttonWidth, buttonHeight))) activeTab = 2;
ImGui::SameLine();
if (ImGui::Button(ICON_FA_ADDRESS_CARD, ImVec2(buttonWidth, buttonHeight))) activeTab = 3;

// fecha tudo corretamente
ImGui::PopStyleVar(3);  // agora sim, fecha todos os PushStyleVar abertos
ImGui::End();


}
        
        ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
        get_players();
        aimbot();
        game_sdk->init();
        

if (Vars.isAimFov && Vars.AimFov > 0) {
    ImVec2 center = ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2);

    if (Vars.fovaimglow) {
        static float rainbowHue = 0.0f;
        rainbowHue += ImGui::GetIO().DeltaTime * 0.8f;
        if (rainbowHue > 1.0f) rainbowHue = 0.0f;

        drawcircleglow(
            draw_list,
            center,
            Vars.AimFov,
            ImColor(fovColor), // usa cor configurada
            100,
            2.0f,
            12
        );
    } else {
        draw_list->AddCircle(
            center,
            Vars.AimFov,
            ImColor(fovColor),
            100,
            2.0f
        );
    }
}


        ImGui::Render();
        ImDrawData* draw_data = ImGui::GetDrawData();
        ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
        [renderEncoder popDebugGroup];
        [renderEncoder endEncoding];
        [commandBuffer presentDrawable:view.currentDrawable];
        [commandBuffer commit];
    } 
} 

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size {}
void hooking() {
void* address[] = {
               (void*)getRealOffset(ENCRYPTOFFSET("0x1044290AC"))
    };
    void* function[] = {
                (void*)antiban                                                     
    };
            hook(address, function, 1);
}
void *hack_thread(void *) {

    sleep(5);
    hooking();
    pthread_exit(nullptr);
    return nullptr;
}

void __attribute__((constructor)) initialize() {
    pthread_t hacks;
    pthread_create(&hacks, NULL, hack_thread, NULL); 
}

- (NSString*)remaningTime:(NSDate*)startDate endDate:(NSDate*)endDate
{
    NSDateComponents *components;
    NSInteger week;
    NSInteger days;
    NSInteger hour;
    NSInteger minutes;
    NSInteger second;
    NSString *durationString;
    
    components = [[NSCalendar currentCalendar] components: NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond fromDate:startDate toDate:endDate options: 0];
    days = [components day];
    week = round(days / 7);
    hour = [components hour];
    minutes = [components minute];
    second = [components second];
    return [NSString stringWithFormat:@"%ld dia(s), %ld h, %ld min, %ld s",days, hour, minutes, second];
}

@end

