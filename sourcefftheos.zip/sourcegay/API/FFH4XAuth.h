//
//  FFH4XAuth.h — FFH4X IPHONE Anti-Cracker Protection
//
//  Proteções incluídas:
//    [1] Anti-Debug    — detecta debugger attachado (PT_DENY_ATTACH + sysctl)
//    [2] Anti-Frida    — detecta Frida agent/server no processo
//    [3] HMAC-SHA256   — verifica assinatura da resposta do servidor
//    [4] Ofuscação     — TODAS as strings encriptadas XOR 0xA5 no binário
//    [5] Revalidação   — recheck periódico a cada 5 min durante uso
//    [6] Keychain      — chave salva no Keychain (não no NSUserDefaults)
//

#pragma once
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CommonCrypto/CommonHMAC.h>
#import <Security/Security.h>
#include <sys/sysctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <string.h>
#include <math.h>

// ═════════════════════════════════════════════════════════════
//  INTERVALO DE REVALIDAÇÃO
// ═════════════════════════════════════════════════════════════
#define FFH4X_RECHECK_INTERVAL  300.0

// ═════════════════════════════════════════════════════════════
//  [4] TODAS AS STRINGS OFUSCADAS — XOR 0xA5
//  Nenhuma string sensível aparece em texto claro no binário.
//  Use S(name) para decodificar em runtime.
// ═════════════════════════════════════════════════════════════

// "52415b4c9dc5876983a695950fc16569d752c4143fb9e33a3cbb3b172816d9e0"
static const uint8_t _s_hmac_key[]         = { 0x90,0x97,0x91,0x94,0x90,0xc7,0x91,0xc6,0x9c,0xc1,0xc6,0x90,0x9a,0x93,0x9c,0x9a,0x96,0x96,0xc4,0x93,0x9c,0x90,0x9c,0x90,0xc3,0xc6,0x94,0x93,0x90,0x93,0x9c,0xc1,0x90,0x97,0xc6,0x91,0x94,0x91,0x96,0xc3,0xc7,0x9c,0x9e,0xc0,0x96,0x96,0xc4,0x96,0xc6,0xc7,0xc7,0x96,0xc7,0x94,0x97,0x97,0x9a,0x94,0x93,0xc1,0x9e,0xc0,0x95 };

// "ffh4x_user_key"
static const uint8_t _s_key_storage[]      = { 0xc3,0xc3,0xcd,0x91,0xdd,0xfa,0xd0,0xd6,0xc0,0xd7,0xfa,0xce,0xc0,0xdc };

// "com.ffh4x.rage"  (Keychain service)
static const uint8_t _s_keychain_svc[]     = { 0xc6,0xca,0xc8,0x8b,0xc3,0xc3,0xcd,0x91,0xdd,0x8b,0xd7,0xc4,0xc2,0xc0 };

// "user_key"  (Keychain account)
static const uint8_t _s_keychain_acc[]     = { 0xd0,0xd6,0xc0,0xd7,0xfa,0xce,0xc0,0xdc };

// "PAINEL FFH4X MOBILE"
static const uint8_t _s_app_title[]        = { 0xf5,0xe4,0xec,0xeb,0xe0,0xe9,0x85,0xe3,0xe3,0xed,0x91,0xfd,0x85,0xe8,0xea,0xe7,0xec,0xe9,0xe0 };

// "Fechar"
static const uint8_t _s_btn_close[]        = { 0xe3,0xc0,0xc6,0xcd,0xc4,0xd7 };

// "Validar"
static const uint8_t _s_btn_validate[]     = { 0xf3,0xc4,0xc9,0xcc,0xc1,0xc4,0xd7 };

// "Digite sua chave de acesso:"
static const uint8_t _s_ask_msg[]          = { 0xe1,0xcc,0xc2,0xcc,0xd1,0xc0,0x85,0xd6,0xd0,0xc4,0x85,0xc6,0xcd,0xc4,0xd3,0xc0,0x85,0xc1,0xc0,0x85,0xc4,0xc6,0xc0,0xd6,0xd6,0xca,0x9f };

// "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
static const uint8_t _s_key_placeholder[]  = { 0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd,0xfd };

// "frida_agent_main"
static const uint8_t _s_frida_sym[]        = { 0xc3,0xd7,0xcc,0xc1,0xc4,0xfa,0xc4,0xc2,0xc0,0xcb,0xd1,0xfa,0xc8,0xc4,0xcc,0xcb };

// "/api/license/validate"
static const uint8_t _s_api_path[]         = { 0x8a,0xc4,0xd5,0xcc,0x8a,0xd3,0xc0,0xd7,0xcc,0xc3,0xdc,0x88,0xd1,0xca,0xce,0xc0,0xcb };

// "application/json"
static const uint8_t _s_content_type[]     = { 0xc4,0xd5,0xd5,0xc9,0xcc,0xc6,0xc4,0xd1,0xcc,0xca,0xcb,0x8a,0xcf,0xd6,0xca,0xcb };

// "Content-Type"
static const uint8_t _s_hdr_ctype[]        = { 0xe6,0xca,0xcb,0xd1,0xc0,0xcb,0xd1,0x88,0xf1,0xdc,0xd5,0xc0 };

// "X-Package-Token"
static const uint8_t _s_hdr_pkg[]          = { 0xfd,0x88,0xf5,0xc4,0xc6,0xce,0xc4,0xc2,0xc0,0x88,0xf1,0xca,0xce,0xc0,0xcb };

// "X-FFH4X-Sig"
static const uint8_t _s_hdr_sig[]          = { 0xfd,0x88,0xe3,0xe3,0xed,0x91,0xfd,0x88,0xf6,0xcc,0xc2 };

// "token"
static const uint8_t _s_json_token[]       = { 0xd1,0xca,0xce,0xc0,0xcb };

// "valid"
static const uint8_t _s_json_valid[]       = { 0xd3,0xc4,0xc9,0xcc,0xc1 };

// "error"
static const uint8_t _s_json_error[]       = { 0xc0,0xd7,0xd7,0xca,0xd7 };

// "ts"
static const uint8_t _s_json_ts[]          = { 0xd1,0xd6 };

// "Sem conexao. Verifique sua internet."
static const uint8_t _s_err_nonet[]        = { 0xf6,0xc0,0xc8,0x85,0xc6,0xca,0xcb,0xc0,0xdd,0xc4,0xca,0x8b,0x85,0xf3,0xc0,0xd7,0xcc,0xc3,0xcc,0xd4,0xd0,0xc0,0x85,0xd6,0xd0,0xc4,0x85,0xcc,0xcb,0xd1,0xc0,0xd7,0xcb,0xc0,0xd1,0x8b };

// "Resposta invalida. Possivel adulteracao detectada."
static const uint8_t _s_err_hmac[]         = { 0xf7,0xc0,0xd6,0xd5,0xca,0xd6,0xd1,0xc4,0x85,0xcc,0xcb,0xd3,0xc4,0xc9,0xcc,0xc1,0xc4,0x8b,0x85,0xf5,0xca,0xd6,0xd6,0xcc,0xd3,0xc0,0xc9,0x85,0xc4,0xc1,0xd0,0xc9,0xd1,0xc0,0xd7,0xc4,0xc6,0xc4,0xc0,0x85,0xc1,0xc0,0xd1,0xc0,0xc6,0xd1,0xc4,0xc1,0xc4,0x8b };

// "Erro de resposta do servidor."
static const uint8_t _s_err_server[]       = { 0xe0,0xd7,0xd7,0xca,0x85,0xc1,0xc0,0x85,0xd7,0xc0,0xd6,0xd5,0xca,0xd6,0xd1,0xc4,0x85,0xc1,0xca,0x85,0xd6,0xc0,0xd7,0xd3,0xcc,0xc1,0xca,0xd7,0x8b };

// "Chave invalida ou banida."
static const uint8_t _s_err_key[]          = { 0xe6,0xcd,0xc4,0xd3,0xc0,0x85,0xcc,0xcb,0xd3,0xc4,0xc9,0xcc,0xc1,0xc4,0x85,0xca,0xd0,0x85,0xc7,0xc4,0xcb,0xcc,0xc1,0xc4,0x8b };

// "Resposta expirada. Possivel replay attack."
static const uint8_t _s_err_replay[]       = { 0xf7,0xc0,0xd6,0xd5,0xca,0xd6,0xd1,0xc4,0x85,0xc0,0xdd,0xd5,0xcc,0xd7,0xc4,0xc1,0xc4,0x8b,0x85,0xf5,0xca,0xd6,0xd6,0xcc,0xd3,0xc0,0xc9,0x85,0xd7,0xc0,0xd5,0xc9,0xc4,0xdc,0x85,0xc4,0xd1,0xd1,0xc4,0xc6,0xce,0x8b };

// "Sessao encerrada. Reabra o app."
static const uint8_t _s_err_session[]      = { 0xf6,0xc0,0xd6,0xd6,0xc4,0xca,0x85,0xc0,0xcb,0xc6,0xc0,0xd7,0xd7,0xc4,0xc1,0xc4,0x8b,0x85,0xf7,0xc0,0xc4,0xc7,0xd7,0xc4,0x85,0xca,0x85,0xc4,0xd5,0xd5,0x8b };

// ─────────────────────────────────────────────────────────────
//  URL e packageToken ofuscados com XOR 0xA5
//  URL: https://api-production-182c.up.railway.app
//  PKG: 52415b4c9dc5876983a695950fc16569d752c4143fb9e33a3cbb3b172816d9e0
// ─────────────────────────────────────────────────────────────
static const uint8_t _ffh4x_url_enc[] = {
    0xcd,0xd1,0xd1,0xd5,0xd6,0x9f,0x8a,0x8a,0xc4,0xd5,
    0xcc,0x88,0xd5,0xd7,0xca,0xc1,0xd0,0xc6,0xd1,0xcc,
    0xca,0xcb,0x88,0x94,0x9d,0x97,0xc6,0x8b,0xd0,0xd5,
    0x8b,0xd7,0xc4,0xcc,0xc9,0xd2,0xc4,0xdc,0x8b,0xc4,
    0xd5,0xd5,
};

static const uint8_t _ffh4x_pkg_enc[] = {
    0x90,0x97,0x91,0x94,0x90,0xc7,0x91,0xc6,0x9c,0xc1,
    0xc6,0x90,0x9d,0x92,0x93,0x9c,0x9d,0x96,0xc4,0x93,
    0x9c,0x90,0x9c,0x90,0x95,0xc3,0xc6,0x94,0x93,0x90,
    0x93,0x9c,0xc1,0x92,0x90,0x97,0xc6,0x91,0x94,0x91,
    0x96,0xc3,0xc7,0x9c,0xc0,0x96,0x96,0xc4,0x96,0xc6,
    0xc7,0xc7,0x96,0xc7,0x94,0x92,0x97,0x9d,0x94,0x93,
    0xc1,0x9c,0xc0,0x95
};

// ═════════════════════════════════════════════════════════════
//  Macro S(name) — decodifica XOR em runtime, retorna NSString
//  A string decodificada é alocada no stack e liberada logo após uso.
//  Nenhum texto claro fica no segmento __cstring do binário.
// ═════════════════════════════════════════════════════════════
#define S(name) ({ \
    size_t _len = sizeof(_s_##name); \
    char *_buf = (char *)alloca(_len + 1); \
    for (size_t _i = 0; _i < _len; _i++) _buf[_i] = (char)(_s_##name[_i] ^ 0xA5); \
    _buf[_len] = '\0'; \
    [NSString stringWithUTF8String:_buf]; \
})

// Decodificador genérico para arrays sem macro S (URL e PKG)
static NSString *_ffh4x_decode(const uint8_t *enc, size_t len) {
    char *buf = (char *)malloc(len + 1);
    for (size_t i = 0; i < len; i++) buf[i] = (char)(enc[i] ^ 0xA5);
    buf[len] = '\0';
    NSString *s = [NSString stringWithUTF8String:buf];
    free(buf);
    return s;
}

#define FFH4X_SERVER_URL()  _ffh4x_decode(_ffh4x_url_enc, sizeof(_ffh4x_url_enc))
#define FFH4X_PKG_TOKEN()   _ffh4x_decode(_ffh4x_pkg_enc, sizeof(_ffh4x_pkg_enc))
#define FFH4X_HMAC_KEY_NS() S(hmac_key)

// ═════════════════════════════════════════════════════════════

static BOOL     _ffh4x_validated = NO;
static BOOL     _ffh4x_started   = NO;
static NSTimer *_ffh4x_timer     = nil;

// ─────────────────────────────────────────────────────────────
//  Função para verificar se está validado (acessível externamente)
// ─────────────────────────────────────────────────────────────
static inline BOOL FFH4X_IsValidated(void) {
    return _ffh4x_validated;
}

// ─────────────────────────────────────────────────────────────
//  [6] KEYCHAIN — salva/carrega/apaga chave no Secure Enclave
// ─────────────────────────────────────────────────────────────
static void _ffh4x_keychain_save(NSString *key) {
    NSData *data = [key dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *query = @{
        (__bridge id)kSecClass:            (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService:      S(keychain_svc),
        (__bridge id)kSecAttrAccount:      S(keychain_acc),
        (__bridge id)kSecValueData:        data,
        (__bridge id)kSecAttrAccessible:   (__bridge id)kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    SecItemAdd((__bridge CFDictionaryRef)query, NULL);
}

static NSString *_ffh4x_keychain_load(void) {
    NSDictionary *query = @{
        (__bridge id)kSecClass:       (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: S(keychain_svc),
        (__bridge id)kSecAttrAccount: S(keychain_acc),
        (__bridge id)kSecMatchLimit:  (__bridge id)kSecMatchLimitOne,
        (__bridge id)kSecReturnData:  @YES
    };
    CFTypeRef result = NULL;
    if (SecItemCopyMatching((__bridge CFDictionaryRef)query, &result) == errSecSuccess) {
        NSData *data = (__bridge_transfer NSData *)result;
        return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    return nil;
}

static void _ffh4x_keychain_delete(void) {
    NSDictionary *query = @{
        (__bridge id)kSecClass:       (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: S(keychain_svc),
        (__bridge id)kSecAttrAccount: S(keychain_acc)
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
}

// ─────────────────────────────────────────────────────────────
//  [1] ANTI-DEBUG — PT_DENY_ATTACH + sysctl kinfo_proc
// ─────────────────────────────────────────────────────────────
static BOOL _ffh4x_debugger_present(void) {
    struct kinfo_proc info;
    size_t size = sizeof(info);
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid() };
    memset(&info, 0, sizeof(info));
    if (sysctl(mib, 4, &info, &size, NULL, 0) == 0) {
        if (info.kp_proc.p_flag & P_TRACED) return YES;
    }
    return NO;
}

static void FFH4X_AntiDebug(void) {
    typedef int (*ptrace_fn)(int, pid_t, caddr_t, int);
    ptrace_fn pt = (ptrace_fn)dlsym(RTLD_DEFAULT, "ptrace");
    if (pt) pt(31 /*PT_DENY_ATTACH*/, 0, 0, 0);
    if (_ffh4x_debugger_present()) exit(0);
}

// ─────────────────────────────────────────────────────────────
//  [2] ANTI-FRIDA
// ─────────────────────────────────────────────────────────────
static BOOL _ffh4x_frida_present(void) {
    // 1. Verifica imagens dyld carregadas no processo
    uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char *name = _dyld_get_image_name(i);
        if (!name) continue;
        if (strstr(name, "frida")     ||
            strstr(name, "cynject")   ||
            strstr(name, "libcycript")) return YES;
    }

    // 2. Tenta conectar na porta 27042 (frida-server padrão)
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock >= 0) {
        struct timeval tv = { 0, 300000 };
        setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family      = AF_INET;
        addr.sin_port        = htons(27042);
        addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) == 0) {
            close(sock);
            return YES;
        }
        close(sock);
    }

    // 3. Verifica símbolo frida_agent_main — ofuscado, sem string clara no binário
    NSString *fridaSym = S(frida_sym);
    if (dlsym(RTLD_DEFAULT, fridaSym.UTF8String)) return YES;

    return NO;
}

static void FFH4X_AntiFrida(void) {
    if (_ffh4x_frida_present()) exit(0);
}

// ─────────────────────────────────────────────────────────────
//  [3] HMAC-SHA256 — verifica assinatura da resposta do servidor
// ─────────────────────────────────────────────────────────────
static BOOL _ffh4x_verify_hmac(NSData *body, NSString *sigHex) {
    if (!body || !sigHex || sigHex.length != 64) return NO;

    NSString *keyNS = FFH4X_HMAC_KEY_NS();
    const char *key = keyNS.UTF8String;
    size_t keyLen   = strlen(key);

    uint8_t digest[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, key, keyLen, body.bytes, body.length, digest);

    NSMutableString *computed = [NSMutableString stringWithCapacity:64];
    for (int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++)
        [computed appendFormat:@"%02x", digest[i]];

    // Comparação em tempo constante (evita timing attack)
    const char *a = computed.UTF8String;
    const char *b = sigHex.UTF8String;
    uint8_t diff = 0;
    for (int i = 0; i < 64; i++) diff |= (uint8_t)(a[i] ^ b[i]);
    return (diff == 0);
}

// ─────────────────────────────────────────────────────────────
//  Helper: root view controller
// ─────────────────────────────────────────────────────────────
static UIViewController *_ffh4x_root_vc(void) {
    UIWindow *keyWindow = nil;
    for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
        if ([scene isKindOfClass:[UIWindowScene class]]) {
            for (UIWindow *w in ((UIWindowScene *)scene).windows) {
                if (w.isKeyWindow) { keyWindow = w; break; }
            }
        }
        if (keyWindow) break;
    }
    if (!keyWindow) keyWindow = [UIApplication sharedApplication].windows.firstObject;
    UIViewController *root = keyWindow.rootViewController;
    while (root.presentedViewController) root = root.presentedViewController;
    return root;
}

// ─────────────────────────────────────────────────────────────
//  Bloqueia o app — limpa keychain e mostra alerta
// ─────────────────────────────────────────────────────────────
static void FFH4X_Block(NSString *reason) {
    if (_ffh4x_timer) { [_ffh4x_timer invalidate]; _ffh4x_timer = nil; }
    _ffh4x_validated = NO;

    dispatch_async(dispatch_get_main_queue(), ^{
        _ffh4x_keychain_delete();

        UIAlertController *alert = [UIAlertController
            alertControllerWithTitle:S(app_title)
            message:reason
            preferredStyle:UIAlertControllerStyleAlert];

        [alert addAction:[UIAlertAction
            actionWithTitle:S(btn_close)
            style:UIAlertActionStyleDestructive
            handler:^(UIAlertAction *a) { exit(0); }]];

        [_ffh4x_root_vc() presentViewController:alert animated:YES completion:nil];
    });
}

// ─────────────────────────────────────────────────────────────
//  Core de validação — usado no login e no recheck periódico
// ─────────────────────────────────────────────────────────────
static void _ffh4x_do_validate(NSString *key, BOOL silent, void(^onSuccess)(void)) {
    FFH4X_AntiDebug();
    FFH4X_AntiFrida();

    NSURL *url = [NSURL URLWithString:@"https://api-production-182c.up.railway.app/api/license/validate"];

    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url
        cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
        timeoutInterval:10.0];

    [req setHTTPMethod:@"POST"];
    [req setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];

    NSString *deviceId = [UIDevice currentDevice].identifierForVendor.UUIDString ?: @"";
    NSString *bundleId = [NSBundle mainBundle].bundleIdentifier ?: @"";
    NSString *appVersion = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"] ?: @"1.0.0";
    NSDictionary *bodyDict = @{
        @"key": key ?: @"",
        @"device_id": deviceId,
        @"package": bundleId,
        @"app_version": appVersion
    };
    req.HTTPBody = [NSJSONSerialization dataWithJSONObject:bodyDict options:0 error:nil];

    NSURLSessionTask *task = [[NSURLSession sharedSession]
        dataTaskWithRequest:req
        completionHandler:^(NSData *data, NSURLResponse *rawResp, NSError *err) {

        if (err || !data) {
            if (!silent) FFH4X_Block(S(err_nonet));
            return;
        }

        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        if (!json) { FFH4X_Block(S(err_server)); return; }

        BOOL valid = [json[@"valid"] boolValue];
        if (!valid) {
            NSString *msg = json[@"message"] ?: S(err_key);
            FFH4X_Block(msg);
            return;
        }

        _ffh4x_validated = YES;
        _ffh4x_keychain_save(key);

        if (!silent && onSuccess) {
            dispatch_async(dispatch_get_main_queue(), ^{ onSuccess(); });
        }
    }];
    [task resume];
}

// ─────────────────────────────────────────────────────────────
//  [5] Timer de revalidação periódica
// ─────────────────────────────────────────────────────────────
static void FFH4X_StartTimer(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (_ffh4x_timer) { [_ffh4x_timer invalidate]; _ffh4x_timer = nil; }
        _ffh4x_timer = [NSTimer scheduledTimerWithTimeInterval:FFH4X_RECHECK_INTERVAL
            target:[NSBlockOperation blockOperationWithBlock:^{
                NSString *saved = _ffh4x_keychain_load();
                if (!saved || saved.length == 0) {
                    FFH4X_Block(S(err_session));
                    return;
                }
                _ffh4x_do_validate(saved, YES, nil);
            }]
            selector:@selector(main)
            userInfo:nil
            repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_ffh4x_timer forMode:NSRunLoopCommonModes];
    });
}

// ─────────────────────────────────────────────────────────────
//  Pede a chave ao usuário via alerta
// ─────────────────────────────────────────────────────────────
static void FFH4X_AskKey(void(^onSuccess)(void));

static void FFH4X_Validate(NSString *key, void(^onSuccess)(void)) {
    NSLog(@"[FFH4X] FFH4X_Validate() chamado");
    NSLog(@"[FFH4X] Chave recebida: %@", key);
    
    // Validação básica local antes de enviar ao servidor
    if (key.length < 8) {
        NSLog(@"[FFH4X] Chave muito curta (<8 chars)");
        FFH4X_Block(S(err_key));
        return;
    }
    
    // Validação COM SERVIDOR
    NSLog(@"[FFH4X] Iniciando validação com servidor...");
    _ffh4x_do_validate(key, NO, ^{
        NSLog(@"[FFH4X] Validação com servidor SUCESSO!");
        NSLog(@"[FFH4X] Iniciando timer de revalidação...");
        FFH4X_StartTimer();
        if (onSuccess) {
            NSLog(@"[FFH4X] Executando callback onSuccess");
            onSuccess();
        }
    });
}

static void FFH4X_AskKey(void(^onSuccess)(void)) {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alert = [UIAlertController
            alertControllerWithTitle:S(app_title)
            message:S(ask_msg)
            preferredStyle:UIAlertControllerStyleAlert];

        [alert addTextFieldWithConfigurationHandler:^(UITextField *tf) {
            tf.placeholder            = S(key_placeholder);
            tf.autocorrectionType     = UITextAutocorrectionTypeNo;
            tf.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        }];

        [alert addAction:[UIAlertAction
            actionWithTitle:S(btn_validate)
            style:UIAlertActionStyleDefault
            handler:^(UIAlertAction *a) {
                NSString *key = alert.textFields.firstObject.text;
                if (!key || key.length < 8) { FFH4X_AskKey(onSuccess); return; }
                FFH4X_Validate(key, onSuccess);
            }]];

        [alert addAction:[UIAlertAction
            actionWithTitle:S(btn_close)
            style:UIAlertActionStyleDestructive
            handler:^(UIAlertAction *a) { exit(0); }]];

        [_ffh4x_root_vc() presentViewController:alert animated:YES completion:nil];
    });
}

// ─────────────────────────────────────────────────────────────
//  FUNÇÃO PRINCIPAL — chame no início do tweak
// ─────────────────────────────────────────────────────────────
static void FFH4X_Start(void(^onSuccess)(void)) {
    NSLog(@"[FFH4X] FFH4X_Start() chamado");
    NSLog(@"[FFH4X] _ffh4x_started: %d", _ffh4x_started);
    NSLog(@"[FFH4X] _ffh4x_validated: %d", _ffh4x_validated);
    
    if (_ffh4x_started) {
        NSLog(@"[FFH4X] Já foi iniciado antes");
        if (_ffh4x_validated && onSuccess) {
            NSLog(@"[FFH4X] Já validado, chamando onSuccess");
            dispatch_async(dispatch_get_main_queue(), ^{ onSuccess(); });
        }
        return;
    }
    _ffh4x_started = YES;
    NSLog(@"[FFH4X] Primeira inicialização, _ffh4x_started = YES");

    NSLog(@"[FFH4X] Executando Anti-Debug...");
    FFH4X_AntiDebug();
    NSLog(@"[FFH4X] Executando Anti-Frida...");
    FFH4X_AntiFrida();
    NSLog(@"[FFH4X] Proteções executadas");

    NSLog(@"[FFH4X] Tentando carregar chave do Keychain...");
    NSString *saved = _ffh4x_keychain_load();
    NSLog(@"[FFH4X] Chave carregada: %@", saved ? @"SIM" : @"NÃO");
    
    if (saved && saved.length > 0) {
        NSLog(@"[FFH4X] Chave encontrada, validando automaticamente...");
        FFH4X_Validate(saved, onSuccess);
    } else {
        NSLog(@"[FFH4X] Nenhuma chave salva, mostrando alerta...");
        FFH4X_AskKey(onSuccess);
    }
}
