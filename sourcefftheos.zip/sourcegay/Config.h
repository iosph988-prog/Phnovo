#ifndef CONFIG_H
#define CONFIG_H

// Arquivo vazio - a estrutura Vars_t está definida no Hooks.h
// A função drawcircleglow está definida no vinhtran.hpp

#endif /* CONFIG_H */
